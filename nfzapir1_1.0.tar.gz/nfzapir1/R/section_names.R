#' @title Names of section of Homogeneous Groups of Patients
#'
#' @description Generates names of section of Jednorodne Grupy Pacjentow / Homogeneous Groups of Patients
#' @return Prints character vector with Polish names of Jednorodne Grupy Pacjentow / Homogeneous Groups of Patients
#' @import httr rvest tidyverse jsonlite
#' @export
#' @examples
#' \code{section_names()}

section_names <- function(){
  r <- GET(paste0('https://api.nfz.gov.pl/app-stat-api-jgp/sections?page=1&limit=25&format=json&api-version=1.1'))
  rl <- unlist(content(r)$data)
  rl
}
