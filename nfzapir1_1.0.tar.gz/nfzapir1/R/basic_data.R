#' @title Generates basic information on number of patients and hospitalizations for given Homogeneous Groups of Patients
#'
#' @description Generates basic information on number of patients and hospitalizations for given Homogeneous Groups of Patients and year. Require ID retrieved from search_benefits function. Catalog of products is detected automatically. Catalog of benefits. 1a - Jednorodne Grupy Pacjentow, 1b - Katalog swiadczen odrebnych, 1c - Katalog swiadczen do sumowania, 1d - Katalog swiadczen radioterapii, 1w - Katalog swiadczen wysokospecjalistycznych.
#' @param name Code of benefits retrieved from function search_benefits
#' @param division Option to divide the generated data based on hospital type (type: 'hospitalType') or branch of National Health Fund (type: 'branch')
#' @param first_page Natural number of first page. Default 1.
#' @param last_page Natural number of last page. Default '' which means that function will automatically search for the last page.
#' @param year Number representing year from 2009 to 2020. Default includes all available years.
#' @return Tibble with basic information on number of patients and hospitalizations for given year and Generates basic information on number of patients and hospitalizations for given Homogeneous Groups of Patients

#' @import httr rvest tidyverse jsonlite
#' @export basic_data
#' @examples
#' \code{basic_data(name = '5.51.01.0006001')}
#' \code{basic_data(name = '5.51.01.0006001', division='hospitalType')}
#' \code{basic_data(name='5.51.01.0006003', year = 2009)}

basic_data <- function(name, division = 'none', first_page=1, last_page='', year=''){
  if(year==''){
    year <- ''
    year_code <- ''
  } else {
    year_code <- '&year='}

  catal <-  substr(name, 1, 4)
  if(catal=='5.51'){catalog<-'1a'}
  if(catal=='5.52'){catalog<-'1b'}
  if(catal=='5.53'){catalog<-'1c'}
  if(catal=='5.07'){catalog<-'1d'}
  if(catal=='5.54'){catalog<-'1w'}

  r <- GET(paste0('https://api.nfz.gov.pl/app-stat-api-jgp/index-of-tables?catalog=',catalog,'&name=',name,year_code,year,'&format=json&api-version=1.1'))
  rc <- content(r)
  rd <- rc$data$attributes$years
  d <- c()
  if(length(rd) != 0){
    for(y in 1:length(rd)){
      if(is.null(rd[[y]]$year)==TRUE){
        rok <- NA
      }else{
        rok <- rd[[y]]$year}
      for(p in 1:length(rd[[y]]$tables)){
        if(is.null(rd[[y]]$tables[[p]]$type)==TRUE){
          type <- NA
        }else{
          type <- rd[[y]]$tables[[p]]$type}
        if(is.null(rd[[y]]$tables[[p]]$id)==TRUE){
          id <- NA
        }else{
          id <-  rd[[y]]$tables[[p]]$id}
        if(is.null(rd[[y]]$tables[[p]]$links$related)==TRUE){
          link <- NA
        }else{
          link <- rd[[y]]$tables[[p]]$links$related}

        v <- c(rok, id, type, link)
        d <- rbind(d, v)
      }}
    d <- as_tibble(d)
    colnames(d) <- c('year', 'name', 'full_name','link')
    f<- d %>%
      filter(full_name == 'general-data')
    e <- c()

    if(division=='none'){
      div <- '?branch=false&hospitalType=false'  }
    if(division=='branch'){
      div <- '?branch=true&hospitalType=false'  }
    if(division=='hospitalType'){
      div <- '?branch=false&hospitalType=true'  }
    if(nrow(f)!=0){

      for (i in 1:nrow(f)){
        if(last_page==''){
          r <- GET(paste0(f$link[i],div,'&page=',1,'&limit=25&format=json&api-version=1.1'))
          rc <- content(r)
          last_page2 <- (rc$meta$count %/% 25)+1
        } else {last_page2 <- last_page}
        for(pag in first_page:last_page2){
          r <- GET(paste0(f$link[i],div,'&page=',pag,'&limit=25&format=json&api-version=1.1'))
          Sys.sleep(0.1)
          rc <- content(r)
          g <- do.call(rbind, lapply( rc$data$attributes$data, rbind))
          g <- as.data.frame(g)
          g$year <- rc$data$attributes$year
          g$jgp <- rc$data$attributes$code
          e <- e %>%
            bind_rows(g)
        }}} else {
          e2 <- c(NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA)
          e3 <- c('branch', "hospital-types", "number-of-patients", "number-of-hospitalizations",
                  "ratio-of-rehospitalizations", "percentage", "percentage-of-sections",
                  "duration-of-hospitalization-mediana", "duration-of-hospitalization-mode",
                  "average-value-of-hospitalization", "average-value-of-hospitalization-points",
                  "average-value-of-drg", "average-value-of-drg-points")
          e <- setNames(as.data.frame.list(e2), e3)
        }
  } else {
    e2 <- c(NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA)
    e3 <- c('branch', "hospital-types", "number-of-patients", "number-of-hospitalizations",
            "ratio-of-rehospitalizations", "percentage", "percentage-of-sections",
            "duration-of-hospitalization-mediana", "duration-of-hospitalization-mode",
            "average-value-of-hospitalization", "average-value-of-hospitalization-points",
            "average-value-of-drg", "average-value-of-drg-points")
    e <- setNames(as.data.frame.list(e2), e3)
  }
  e[e == 'NULL'] <- NA
  e <- as_tibble(e, .name_repair = 'unique') %>% unnest(cols = c(branch, `hospital-types`, `number-of-patients`, `number-of-hospitalizations`,
                                                                 `ratio-of-rehospitalizations`, percentage, `percentage-of-sections`,
                                                                 `duration-of-hospitalization-mediana`, `duration-of-hospitalization-mode`,
                                                                 `average-value-of-hospitalization`, `average-value-of-hospitalization-points`,
                                                                 `average-value-of-drg`, `average-value-of-drg-points`))
  e %>% distinct()
}
