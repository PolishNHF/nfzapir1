#' @title Generates data source related to given benefits
#' @description Generates data source related to given benefits. All availiable data from index_table() function is stored in index_tables_all list.

#' @param name Code of benefits retrieved from function search_benefits
#' @param year Number representing year from 2009 to 2020. Default includes all available years.
#' @param catalog Catalog of benefits. 1a - Jednorodne Grupy Pacjentow, 1b - Katalog swiadczen odrebnych, 1c - Katalog swiadczen do sumowania, 1d - Katalog swiadczen radioterapii, 1w - Katalog swiadczen wysokospecjalistycznych. Default 'all'. Does not require to manually establish catalog. The function will check it automatically.
#' @return Tibble with variables: year, name (id), full name of variable, and link to the API with name and id
#' @import httr rvest tidyverse jsonlite
#' @export index_tables
#' @examples
#' \code{index_tables(name='5.51.01.0006003')}
#' \code{index_tables(name='5.53.01.0003024', catalog='1c')}


index_tables <- function(catalog='all', name, year=''){

  name <- gsub(" ", "%20", name)

  if(year==''){
    year <- ''
    year_code <- ''
  } else {
    year_code <- '&year='}

  if(catalog == 'all'){
    d <- c()
    catalog_list <- c('1a', '1b', '1c', '1d', '1w')
    for(c in 1:length(catalog_list)){
      Sys.sleep(0.01)
      r <- GET(paste0('https://api.nfz.gov.pl/app-stat-api-jgp/index-of-tables?catalog=',catalog_list[c],'&name=',name,year_code,year,'&format=json&api-version=1.1'))
      rc <- content(r)
      rd <- rc$data$attributes$years
      if(length(rd) != 0){
        for(y in 1:length(rd)){
          if(is.null(rd[[y]]$year)==TRUE){
            rok <- NA
          }else{
            rok <- rd[[y]]$year}
          for(p in 1:length(rd[[y]]$tables)){
            if(is.null(rd[[y]]$tables[[p]]$id)==TRUE){
              id <- NA
            }else{
              id <-  rd[[y]]$tables[[p]]$id}
            if(is.null(rd[[y]]$tables[[p]]$type)==TRUE){
              type <- NA
            }else{
              type <- rd[[y]]$tables[[p]]$type}
            if(is.null(rd[[y]]$tables[[p]]$links$related)==TRUE){
              link <- NA
            }else{
              link <- rd[[y]]$tables[[p]]$links$related}
            v <- c(rok, id, type, link)
            d <- rbind(d, v)
          }}}}}  else {
            r <- GET(paste0('https://api.nfz.gov.pl/app-stat-api-jgp/index-of-tables?catalog=',catalog,'&name=',name,year_code,year,'&format=json&api-version=1.1'))
            rc <- content(r)
            rd <- rc$data$attributes$years
            d <- c()
            if(length(rd) != 0){
              for(y in 1:length(rd)){
                if(is.null(rd[[y]]$year)==TRUE){
                  rok <- NA
                }else{
                  rok <- rd[[y]]$year}
                for(p in 1:length(rd[[y]]$tables)){
                  if(is.null(rd[[y]]$tables[[p]]$id)==TRUE){
                    id <- NA
                  }else{
                    id <-  rd[[y]]$tables[[p]]$id}
                  if(is.null(rd[[y]]$tables[[p]]$type)==TRUE){
                    type <- NA
                  }else{
                    type <- rd[[y]]$tables[[p]]$type}
                  if(is.null(rd[[y]]$tables[[p]]$links$related)==TRUE){
                    link <- NA
                  }else{
                    link <- rd[[y]]$tables[[p]]$links$related}
                  v <- c(rok, id, type, link)
                  d <- rbind(d, v)
                }}}}
  d <- as_tibble(d, .name_repair = 'unique')
  colnames(d) <- c('year', 'name', 'full_name','link')
  d %>% distinct()
}
