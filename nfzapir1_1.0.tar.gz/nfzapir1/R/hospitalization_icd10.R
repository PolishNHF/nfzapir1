#' @title Generates data frame with information on hospitalizations and assigned ICD10.
#'
#' @description Generates data frame with information on hospitalizations and assigned ICD10. The function generates ICD10 codes which were assigned to at least 1% of hospitalizations for given Homogeneous Groups of Patients. Catalog of products is detected automatically. Catalog of benefits. 1a - Jednorodne Grupy Pacjentow, 1b - Katalog swiadczen odrebnych, 1c - Katalog swiadczen do sumowania, 1d - Katalog swiadczen radioterapii, 1w - Katalog swiadczen wysokospecjalistycznych.
#' @param name Code of benefits retrieved from function search_benefits
#' @param first_page Natural number of first page. Default 1.
#' @param last_page Natural number of last page. Default '' which means that function will automatically search for the last page.
#' @param year Number representing year from 2009 to 2020. Default includes all available years.
#' @return Tibble with 7 variables.
#' @import httr rvest tidyverse jsonlite
#' @export hospitalization_icd10
#' @examples
#' \code{#hospitalization_icd10(name = '5.51.01.0006001')}
#' \code{hospitalization_icd10(name = '5.51.01.0006001', year = 2017)}


hospitalization_icd10 <-  function(name, first_page=1, last_page='', year=''){
  if(year==''){
    year <- ''
    year_code <- ''
  } else {
    year_code <- '&year='}

  catal <-  substr(name, 1, 4)
  if(catal=='5.51'){catalog<-'1a'}
  if(catal=='5.52'){catalog<-'1b'}
  if(catal=='5.53'){catalog<-'1c'}
  if(catal=='5.07'){catalog<-'1d'}
  if(catal=='5.54'){catalog<-'1w'}

  r <- GET(paste0('https://api.nfz.gov.pl/app-stat-api-jgp/index-of-tables?catalog=',catalog,'&name=',name,year_code,year,'&format=json&api-version=1.1'))
  rc <- content(r)
  rd <- rc$data$attributes$years
  d <- c()
  if(length(rd) != 0){
    for(y in 1:length(rd)){

      if(is.null(rd[[y]]$year)==TRUE){
        rok <- NA
      }else{
        rok <- rd[[y]]$year}

      for(p in 1:length(rd[[y]]$tables)){
        if(is.null(rd[[y]]$tables[[p]]$type)==TRUE){
          type <- NA
        }else{
          type <- rd[[y]]$tables[[p]]$type}
        if(is.null(rd[[y]]$tables[[p]]$id)==TRUE){
          id <- NA
        }else{
          id <-  rd[[y]]$tables[[p]]$id}
        if(is.null(rd[[y]]$tables[[p]]$links$related)==TRUE){
          link <- NA
        }else{
          link <- rd[[y]]$tables[[p]]$links$related}


        v <- c(rok, id, type, link)
        d <- rbind(d, v)
      }}
    d <- as_tibble(d)
    colnames(d) <- c('year', 'name', 'full_name','link')
    f<-d %>%
      filter(full_name == 'icd-10-diseases')
    e <- c()
    if(nrow(f)!=0){

      for(i in 1:nrow(f)){
        if(last_page==''){
          r <- GET(paste0(f$link[i],'?page=',1,'&limit=25&format=json&api-version=1.1'))
          rc <- content(r)
          last_page2 <- (rc$meta$count %/% 25)+1
        } else {last_page2 <- last_page}
        for(pag in first_page:last_page2){
          r <- GET(paste0(f$link[i],'?page=',pag,'&limit=25&format=json&api-version=1.1'))
          Sys.sleep(0.1)
          rc <- content(r)
          g <- do.call(rbind, lapply( rc$data$attributes$data, rbind))
          g <- as.data.frame(g)
          g$year <- rc$data$attributes$year
          g$jgp <- rc$data$attributes$code
          e <- e %>%
            bind_rows(g)
        }}} else {
          e2 <- c(NA, NA, NA, NA, NA, NA, NA)
          e3 <- c('disease-code','disease-name','number-of-hospitalizations','percentage','duration-of-hospitalization-mediana','year', 'jgp')
          e <- setNames(as.data.frame.list(e2), e3)
        }
  } else {
    e2 <- c(NA, NA, NA, NA, NA, NA, NA)
    e3 <- c('disease-code','disease-name','number-of-hospitalizations','percentage','duration-of-hospitalization-mediana','year', 'jgp')
    e <- setNames(as.data.frame.list(e2), e3)
  }
  e[e == 'NULL'] <- NA
  e <- as_tibble(e)
  e %>%unnest(cols = c(`disease-code`, `disease-name`, `number-of-hospitalizations`,
                       percentage, `duration-of-hospitalization-mediana`, year, jgp)) %>% distinct()
}
