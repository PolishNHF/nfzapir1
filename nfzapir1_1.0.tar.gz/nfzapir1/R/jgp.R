#' List  with details on Homogeneous Groups of Patients in Polish
#'
#' Original list  with details on Jednorodne Grupy Pacjentow / Homogeneous Groups of Patients in Polish. The data comes from announcement Polish National Health Fund from 31 March 2021
#' @docType data
#' @keywords jgp
#' @format List: Name of the version of JGP and tibble with 676 rows and 11 columns in Polish
#' \describe{
#' \item{Lp.}{dbl The order number}
#' \item{Kod grupy}{char The general code of the group}
#' \item{Kod}{char The specific code. This code You will use in many functions in this package}
#' \item{Nazwa}{char Name of the Jednorodne Grupy Pacjentow / Homogeneous Groups of Patients}
#' }
"jgp"
