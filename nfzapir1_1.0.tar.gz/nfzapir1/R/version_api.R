#' @title Generates current version of APIs
#'
#' @description Function provides current version of active APIs used by the package
#' @return Prints six text vectors with current version of National Health Fund APIs and version used in package
#' @import httr rvest tidyverse jsonlite
#' @export version_api
#' @examples
#' \code{version_api()}


version_api<- function(){
  r <- GET(paste0('https://api.nfz.gov.pl/app-stat-api-jgp/version?format=json'))
  rc <- content(r)
  print(paste0('1. API Jednolite Grupy Pacjentow ',rc$`api-version`$major,".",rc$`api-version`$minor,".",rc$`api-version`$patch))
  print(paste0('Wersja API Jednolite Grupy Pacjentow na podstawie ktorej napisano te wersje package: 1.1.0'))
  r <- GET(paste0('https://api.nfz.gov.pl/app-stat-api-ra/version?format=json'))
  rc <- content(r)
  print(paste0('2. API Refundacja Apteczna ',rc$`api-version`$major,".",rc$`api-version`$minor,".",rc$`api-version`$patch))
  print(paste0('Wersja API Refundacja Apteczna na podstawie ktorej napisano te wersje package: 1.0.8'))
  r <- GET(paste0('https://api.nfz.gov.pl/app-stat-api-ch/version?format=json'))
  rc <- content(r)
  print(paste0('3. API Chemioterapia ',rc$`api-version`$major,".",rc$`api-version`$minor,".",rc$`api-version`$patch))
  print(paste0('Wersja API Chemioterapia na podstawie ktorej napisano te wersje package: 1.0.24'))
  r <- GET(paste0('https://api.nfz.gov.pl/app-stat-api-pl/version?format=json'))
  rc <- content(r)
  print(paste0('4. API Programy Lekowe ',rc$`api-version`$major,".",rc$`api-version`$minor,".",rc$`api-version`$patch))
  print(paste0('Wersja API Programy Lekowe na podstawie ktorej napisano te wersje package: 1.0.0'))
  r <- GET(paste0('https://api.nfz.gov.pl/app-itl-api/version?format=json'))
  rc <- content(r)
  print(paste0('5. API Terminy Leczenia ',rc$`api-version`$major,".",rc$`api-version`$minor,".",rc$`api-version`$patch))
  print(paste0('Wersja API Terminy Leczenia na podstawie ktorej napisano te wersje package: 1.3.0'))
  r <- GET(paste0('https://api.nfz.gov.pl/app-umw-api/version?format=json'))
  rc <- content(r)
  print(paste0('6. API Umowy NFZ ',rc$`api-version`$major,".",rc$`api-version`$minor,".",rc$`api-version`$patch))
  print(paste0('Wersja API Umowy NFZ na podstawie ktorej napisano te wersje package: 1.0.0'))
}
